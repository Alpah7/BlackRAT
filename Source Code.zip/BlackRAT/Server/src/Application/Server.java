package Application;

import java.io.IOException;
import java.net.*;
import java.util.concurrent.ConcurrentHashMap;

public class Server {
private ServerSocket server;
private ConcurrentHashMap <Socket,Streams> dialog = new  ConcurrentHashMap <Socket,Streams>();
private ThreadPool tp;
private boolean running = false;
public Server(int port) throws IOException {
	server = new ServerSocket(port);
	tp = new ThreadPool(server,dialog);
 }

public boolean isRunning() {
	return running;
 }
public void startserver() {
    if (isRunning()) throw new IllegalStateException("Server Is Running");
    running = true;
    tp.start();
 }
public void stopserver() throws IOException {
  if (isRunning()) System.out.println("Server Is Stopped");
    running = false;
    server.close();
    tp.shutdown();
    System.exit(1);
}
public ConcurrentHashMap <Socket,Streams> getmap() {
	return dialog;
}
}
